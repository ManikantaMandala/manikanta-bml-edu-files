import smtplib
from email.message import EmailMessage

msg = EmailMessage()
msg.set_content('This is my message')

msg['Subject'] = 'Subject'
msg['From'] = "reflexthecommonfrnd@gmail.com"
msg['To'] = "mandala.manikanta.20cse@bmu.edu.in"

# Send the message via our own SMTP server.
server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
server.login("reflexthecommonfrnd@gmail.com", "121231234")
server.send_message(msg)
server.quit()
