import smtplib as sl
from email.message import EmailMessage

server=sl.SMTP_SSL("smtp.gmail.com",465)

login_mail = "reflexthecommonfrnd@gmail.com"  #email ID
login_password = "121231234" #login password
mail= EmailMessage()
#server.starttls()
# mail["From"]=login_mail
#speech("To whom do you want to send the mail?")
#To=takeCommand(a).lower()
#receiver={"juglal":"boddu.jugalbhaskarnagaganesh.20cse@bmu.edu.in", 
#"bhanu":"naga.bhanukoushikreddyavuthu.20cse@bmu.edu.in ","yashika":"yashika.mittal.20cse@bmu.edu.in","payas":"payas.gakhar.20cse@bmu.edu.in" }
mail['Subject']= "Hi there!!"
mail['From']=login_mail
mail['To']="mandala.manikanta.20cse@bmu.edu.in"
#speech("Tell the Subject")
#subject=takeCommand(a)
#speech("What should I write?")
#content=takeCommand(a)


mail.set_content("Hello Jugal, this is a test")
#to="boddu.jugalbhaskarnagaganesh.20cse@bmu.edu.in"
#content="Hello Jugal, this is a test"
server.login(login_mail,login_password)
print('login successful')
server.send_message(mail)
print('mail sent successfully')
#server.sendmail(login_mail,to,content)
server.quit()




