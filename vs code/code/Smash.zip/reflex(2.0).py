import os
import pyttsx3
import datetime
import speech_recognition as sr
import webbrowser as wb
import wikipedia as wk
import smtplib as sl
from email.message import EmailMessage
from wikipedia import exceptions

receiver={"juglal":"jugalbhaskarnagaganesh.20cse@bmu.edu.in",
"bhanu":"naga.bhanukoushikreddyavuthu.20cse@bmu.edu.in ",
"yashika":"yashika.mittal.20cse@bmu.edu.in","payas":"payas.gakhar.20cse@bmu.edu.in"}

engine =pyttsx3.init()

def speech(text):
    engine.say(text)
    engine.runAndWait()

def wishMe():
    hour=int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speech("Good Morning sir!")
    elif hour>=12 and hour <17:
        speech("Good Afternoon sir!")
    else:
        speech("Good Evening sir!")
    speech("I am reflex,Tell me what to do?")

def takeCommand(a):
    r=sr.Recognizer()
    with sr.Microphone() as source:
        if a==1:
            print("listening..")
        r.adjust_for_ambient_noise(source,duration=1)
        r.pause_threshold=1
        audio=r.listen(source)
    try:
        if a==1:
            print("Recognizing..")
            query=r.recognize_google(audio,language="en-in")
            print(f"recognized:{query}")
    except Exception as e:
        if a==1:
            speech("Say that again!")
        return "none"
    return query

def sendEmail(to,subject,content):
    server=sl.SMTP("smtp.gmail.com",587)
    login_mail="reflexthecommonfrnd@gmail.com"
    login_password="121231234"
    mail=EmailMessage()
    mail['From']=login_mail
    mail['To']=to
    mail['Subject']=subject
    server.login(login_mail,login_password)
    server.send_message(mail)
    server.quit()

if __name__== "__main__":
    wishMe()
    while 1:
        a=0
        first=takeCommand(a).lower()
        if "reflex" in first:
            a=1
            cm=takeCommand(a).lower()
            if "wikipedia" in cm:
                speech("searching in wikipedia")
                cm=cm.replace("wikipedia","")
                speech("According to wikipedia.,")
                speech(wk.summary(cm,sentences=2))
            elif cm=="open youtube":
                wb.open("youtube.com")
            elif cm=="open google":
                wb.open("google.com")
            elif "the time" in cm:
                timeStr=datetime.datetime.now().strftime("%H:%M:%S")
                speech(f"the time is {timeStr}")
            elif "send a mail" in cm:
                try:
                    speech("To whom do you want to send the mail?")
                    to=takeCommand(a).lower()
                    speech("what is the subject?")
                    subject=takeCommand(a)
                    speech("What should I write?")
                    content=takeCommand(a)
                    sendEmail(receiver[to],subject,content)
                    speech("email is sent!")
                except Exception as e:
                    print(e)
                    speech("email not sent!")
            elif "play music" in cm:
                music_dir="/home/kali/Videos/"
                song=os.listdir(music_dir)
                os.startfile(os.path.join(music_dir,song[0]))
            elif "open prime video" in cm:
                wb.open("primevideo.com")
            elif "set a remainder" in cm:
		pass
